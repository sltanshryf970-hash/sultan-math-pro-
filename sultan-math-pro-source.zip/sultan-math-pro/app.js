const sections = [
 {id:"diff",name:"التفاضل والاشتقاق",icon:"∂",ops:[["diff","المشتقة"],["nthdiff","مشتقة من الرتبة n"],["simplify","تبسيط التعبير"]]},
 {id:"integral",name:"التكامل",icon:"∫",ops:[["integrate","تكامل غير محدد"],["defint","تكامل محدد"]]},
 {id:"limit",name:"النهايات",icon:"lim",ops:[["limit","نهاية عند قيمة"],["limitinf","نهاية عند اللانهاية"]]},
 {id:"complex",name:"الأعداد المركبة",icon:"ℂ",ops:[["complex","تبسيط عدد مركب"],["modulus","المقياس"],["argument","السعة بالراديان"],["conjugate","المرافق"]]},
 {id:"algebra",name:"المحددات والجبر",icon:"▦",ops:[["simplify","تبسيط جبري"],["factor","تحليل إلى عوامل"],["expand","نشر الأقواس"],["solve","حل معادلة بالنسبة للمتغير"],["det","محدد مصفوفة 2×2 أو 3×3"],["inverse","معكوس مصفوفة"]]},
 {id:"combinatorics",name:"التوافيق والتباديل والمضروب",icon:"nCr",ops:[["factorial","مضروب n"],["comb","التوافيق nCr"],["perm","التباديل nPr"]]},
 {id:"trigids",name:"المتطابقات المثلثية",icon:"≡",ops:[["trigsimplify","تبسيط مثلثي"],["trigexpand","نشر مثلثي"]]},
 {id:"trig",name:"الدوال المثلثية",icon:"sin",ops:[["trigvalue","حساب دالة مثلثية"]]},
 {id:"series",name:"المتسلسلات والمتتابعات",icon:"Σ",ops:[["sum","مجموع متتابعة حسابية"],["geom","مجموع متتابعة هندسية"],["taylor","متسلسلة تايلور (تقريب)"]]},
 {id:"ode",name:"المعادلات التفاضلية",icon:"y′",ops:[["ode1","حل معادلة بسيطة من الصورة y′=f(x)"]]},
 {id:"logs",name:"اللوغاريتمات",icon:"log",ops:[["diff","اشتقاق تعبير لوغاريتمي"],["integrate","تكامل تعبير لوغاريتمي"],["logvalue","حساب لوغاريتم"]]}
];
let current=sections[0];
const $=id=>document.getElementById(id);
function normalize(s){return s.replace(/٫/g,'.').replace(/،/g,',').replace(/س/g,'x').replace(/ظا/g,'tan').replace(/جا/g,'sin').replace(/جتا/g,'cos').replace(/ظتا/g,'cot').replace(/قا/g,'sec').replace(/قتا/g,'csc').replace(/لوغ/g,'log').replace(/ln/g,'log');}
function setSection(sec){
 current=sec;$("sectionTitle").textContent=sec.name;
 document.querySelectorAll(".cat").forEach(b=>b.classList.toggle("active",b.dataset.id===sec.id));
 $("operation").innerHTML=sec.ops.map(o=>`<option value="${o[0]}">${o[1]}</option>`).join("");
 $("orderWrap").style.display=["diff","nthdiff","limit","limitinf","factorial","comb","perm","trigvalue","logvalue","sum","geom","taylor"].includes(sec.ops[0][0])?"block":"block";
 renderExtra(); $("output").textContent="اكتب المسألة واضغط احسب.";
}
function renderExtra(){
 const op=$("operation").value; let html="";
 if(op==="defint"||op==="limit") html=`<div class="field"><label for="lower">الحد السفلي / قيمة الاقتراب</label><input id="lower" value="0" dir="ltr"></div>`;
 if(op==="defint") html+=`<div class="field"><label for="upper">الحد العلوي</label><input id="upper" value="1" dir="ltr"></div>`;
 if(op==="limitinf") html=`<div class="field"><label for="direction">الاتجاه</label><select id="direction"><option value="positive">موجب ما لا نهاية</option><option value="negative">سالب ما لا نهاية</option></select></div>`;
 if(op==="comb"||op==="perm") html=`<div class="field"><label for="second">قيمة r</label><input id="second" value="2" dir="ltr"></div>`;
 if(op==="trigvalue") html=`<div class="field"><label for="angleMode">وحدة الزاوية</label><select id="angleMode"><option value="rad">راديان</option><option value="deg">درجات</option></select></div>`;
 if(op==="sum"||op==="geom"||op==="taylor") html=`<div class="field"><label for="second">الحد الثاني / عدد الحدود</label><input id="second" value="5" dir="ltr"></div>`;
 if(op==="det"||op==="inverse") html=`<div class="field"><label for="matrix">المصفوفة (افصل الصفوف بفاصلة منقوطة)</label><input id="matrix" value="1,2;3,4" dir="ltr"></div>`;
 if(op==="logvalue") html=`<div class="field"><label for="base">الأساس</label><input id="base" value="10" dir="ltr"></div>`;
 $("extraFields").innerHTML=html;
}
function nval(id,def=0){let v=Number($(id)?.value??def);if(!Number.isFinite(v))throw Error("راجع القيم الرقمية المدخلة.");return v}
function sym(expr){if(!window.nerdamer)throw Error("محرك الجبر لم يتم تحميله. اتصل بالإنترنت وافتح التطبيق مرة أخرى.");return nerdamer(normalize(expr));}
function matrixFrom(s){return s.split(";").map(r=>r.split(",").map(Number))}
function calculate(){
 try{
 const raw=$("expression").value.trim(), x=$("variable").value.trim()||"x", op=$("operation").value, order=Math.max(0,Math.floor(nval("order",1)));
 if(!raw && !["factorial","sum","geom"].includes(op))throw Error("اكتب التعبير الرياضي الأول.");
 let e=normalize(raw), out="";
 switch(op){
 case "diff": out=nerdamer.diff(e,x).toString();break;
 case "nthdiff": {let z=e;for(let i=0;i<order;i++)z=nerdamer.diff(z,x).toString();out=z;break;}
 case "integrate": out=nerdamer.integrate(e,x).toString()+" + C";break;
 case "defint": {let a=nval("lower"),b=nval("upper");out=nerdamer(`integrate(${e},${x})`).evaluate().toString();let F=nerdamer.integrate(e,x);out=`F(${b}) - F(${a}) = ${nerdamer(F.toString().replaceAll(x,`(${b})`)).subtract(F.toString().replaceAll(x,`(${a})`)).toString()}`;break;}
 case "limit": out=nerdamer(`limit(${e},${x},${nval("lower")})`).toString();break;
 case "limitinf": out=nerdamer(`limit(${e},${x},${$("direction").value==="positive"?"Infinity":"-Infinity"})`).toString();break;
 case "complex": out=math.format(math.simplify(e),{precision:14});break;
 case "modulus": out=String(math.abs(math.evaluate(e)));break;
 case "argument": out=String(math.arg(math.evaluate(e)))+" راديان";break;
 case "conjugate": out=String(math.conj(math.evaluate(e)));break;
 case "simplify": out=sym(e).simplify().toString();break;
 case "factor": out=nerdamer(`factor(${e})`).toString();break;
 case "expand": out=nerdamer(`expand(${e})`).toString();break;
 case "solve": out=nerdamer.solve(e,x).toString();break;
 case "det": out=String(math.det(matrixFrom($("matrix").value)));break;
 case "inverse": out=math.format(math.inv(matrixFrom($("matrix").value)));break;
 case "factorial": out=String(math.factorial(nval("order")));break;
 case "comb": out=String(math.combinations(nval("order"),nval("second")));break;
 case "perm": out=String(math.permutations(nval("order"),nval("second")));break;
 case "trigsimplify": out=nerdamer(`trigsimp(${e})`).toString();break;
 case "trigexpand": out=nerdamer(`expand(${e})`).toString();break;
 case "trigvalue": {let v=nval("order");if($("angleMode").value==="deg")v=v*Math.PI/180;out=String(math.evaluate(`${e.replaceAll("x",`(${v})`)}`));break;}
 case "sum": {let a=nval("order"),n=nval("second");out=String(n*(2*a+(n-1)*1)/2)+" (اعتبارًا من حد أول a وفارق 1)";break;}
 case "geom": {let a=nval("order"),r=nval("second"),n=nval("upper",5);out=String(r===1?a*n:a*(1-Math.pow(r,n))/(1-r));break;}
 case "taylor": out="اكتب الدالة في صورة قابلة للتوسيع، واستخدم expand حول نقطة الصفر يدويًا في هذا الإصدار. دعم تايلور العام قيد التطوير.";break;
 case "ode1": out=`y = ∫(${e}) dx + C = ${nerdamer.integrate(e,x).toString()} + C`;break;
 case "logvalue": out=String(Math.log(nval("order"))/Math.log(nval("base",10)));break;
 default: throw Error("العملية دي لسه مش متاحة.");
 }
 $("output").textContent=out;$("status").textContent="تم الحساب";
 }catch(err){$("output").textContent="تعذر الحساب: "+(err.message||String(err))+"\nراجع صيغة المعادلة والقيم المدخلة."; $("status").textContent="راجع المدخلات";}
}
$("categories").innerHTML=sections.map(s=>`<button class="cat" data-id="${s.id}"><span class="ico">${s.icon}</span><span>${s.name}</span></button>`).join("");
document.querySelectorAll(".cat").forEach((b,i)=>b.addEventListener("click",()=>setSection(sections[i])));
$("operation").addEventListener("change",renderExtra);$("calculate").addEventListener("click",calculate);
$("clear").addEventListener("click",()=>{$("expression").value="";$("output").textContent="النتيجة هتظهر هنا.";$("status").textContent="جاهز للحساب";});
$("year").textContent=new Date().getFullYear();setSection(sections[0]);
let deferredPrompt;window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("installBtn").hidden=false;});
$("installBtn").addEventListener("click",async()=>{if(deferredPrompt){deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;}});
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));